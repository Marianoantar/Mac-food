export interface Producto {
  id: number,
  nombre: string,
  precio: string,
  esVegano: boolean,
  esCeliaco: boolean,
  ingredientes: string,
  fotoUrl: string
}
