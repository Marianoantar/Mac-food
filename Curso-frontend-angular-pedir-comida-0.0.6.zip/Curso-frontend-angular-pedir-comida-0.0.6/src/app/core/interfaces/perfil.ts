interface Perfil {
  nombre: string,
  direccion: string,
  detalleEntrega: string,
  telefono?: string,
}
